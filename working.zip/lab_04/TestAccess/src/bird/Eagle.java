package bird;

/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxx@cn103>
 */
public class Eagle {
    private int age;

    public Eagle(int age) {
        this.age = age;
    }

    int getAge() {
        return age;
    }

    void setAge(int age) {
        this.age = age;
    }
}

