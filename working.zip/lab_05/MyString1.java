/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxx@cn103>
 */
public class MyString1 {

    public static void main(String[] args) {
        String s1 = "Good morning";
        String s2 = "the Land of smile";

        // concatenate string with String's method
        String s3 = s1.concat(s2);

        // concatenate strings with operator
        String s4 = s1 + s2;

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(s4);
        System.out.println(s1 + " " + s2);
    }
}

/* Answer the following questions.
1. How many interned String objects are created in this program?
Ans:



2. How many normal String objects (not interned String) are created in this program?
Ans:



/* Write output of this program.





*/

