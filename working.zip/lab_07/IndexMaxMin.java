/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxx@cn103>
 */
public class IndexMaxMin {
    public static void main(String[] args) {

    }
}

