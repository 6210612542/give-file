/*
 * FILE: Hello.java
 * TASK: lab_01
 * LANG: JAVA
 * ID:   6210612559
 */
 
/* Add your code here */
// The "import" keyword imports class(es) from a given package.
// This "import java.lang.*" imports all classes from "java.lang" package.
// This import can be removed since package "java.lang" is imported by default.
import java.lang.*;

public class Hello {

    public static void main(String[] args) {
        System.out.println("Hello programming");
    }
}
