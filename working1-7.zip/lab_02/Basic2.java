/*
 * FILE: Basic2.java
 * TASK: lab_02
 * LANG: JAVA
 * ID:   6210612559
 */

public class Basic2 {

    // Attributes (fields)
    int mFirst;
    int mSecond;

    // Operations (methods)

    public static void main(String[] args) {
        System.out.println("In Class: Basic2");
        System.out.println("   Fields:");
        System.out.println("      mFirst");
        System.out.println("      mSecond");
        System.out.println("   Methods:");
        System.out.println("      main");
    }

}


/* Write down the following information contained in this file.

Class name:
Basic2


All attribute(field) names:
mFirst
mSecond

All operation(method) names:
main



*/