/*
 * FILE: Basic5.java
 * TASK: lab_02
 * LANG: JAVA
 * ID:   6210612559
 */

public class Basic5 {

    // Attributes (fields)
    int mFirst;
    int mSecond;

    private int mX;
    private int mY;

    protected int pX;
    protected int pY;

    public int XX;
    public int YY;

    // Operations (methods)
    void testFirst() { }
    void testSecond() { }
    void setFirst(int x) { mFirst = x; }
    void setSecond(int x) { mSecond = x; }
    int getFirst() { return mFirst; }
    int getSecond() { return mSecond; }

    private void testPrivateX() { }
    private void testPrivateY() { }

    protected void testProtectedX() { }
    protected void testProtectedY() { }

    public void testPublicX() { }
    public void testPublicY() { }

    public static void main(String[] args) {
        System.out.println("In Class: Basic5");
        System.out.println("   Fields:");
        System.out.println("      mFirst");
        System.out.println("      mSecond");
        System.out.println("      mX");
        System.out.println("      mY");
        System.out.println("      pX");
        System.out.println("      pY");
        System.out.println("      XX");
        System.out.println("      XY");
        System.out.println("   Methods:");
        System.out.println("      main");
        System.out.println("      testFirst");
        System.out.println("      testSecond");
        System.out.println("      getFirst");
        System.out.println("      getSecond");
        System.out.println("      setFirst");
        System.out.println("      setSecond");
        System.out.println("      testPrivateX");
        System.out.println("      testPrivateY");
        System.out.println("      testProtectedX");
        System.out.println("      testProtectedY");
        System.out.println("      testPublicX");
        System.out.println("      testPublicY");
    }

}


/* Write down the following information contained in this file.

Class name:
Basic5


All attribute(field) names:
mFirst
mSecond
mX
mY
pX
pY
XX
XY


All operation(method) names:
main
testFirst
testSecond
getFirst
getSecond
setFirst
setSecond
testPrivateX
testPrivateY
testProtectedX
testProtectedY
testPublicX
testPublicY





*/