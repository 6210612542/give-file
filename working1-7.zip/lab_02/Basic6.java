/*
 * FILE: Basic6.java
 * TASK: lab_02
 * LANG: JAVA
 * ID:   6210612559
 */

public class Basic6 {

    // Attributes (fields)
    int mX, mY;

    // Operations (methods)
    void testOne() { }
    void testOne(int x) { }
    void testOne(int x, int y) { }
    int testTwo() { return 0; }
    int testTwo(int x) { return 0; }
    int testTwo(int x, int y) { return 0; }

    public static void main(String[] args) {
        System.out.println("In Class: Basic6");
        System.out.println("   Fields:");
        System.out.println("      mX");
        System.out.println("      mY");
        System.out.println("   Methods:");
        System.out.println("      main");
        System.out.println("      testOne : no argument");
        System.out.println("      testOne : 1 argument");
        System.out.println("      testOne : 2 arguments");
        System.out.println("      testTwo : no argument");
        System.out.println("      testTwo : 1 argument");
        System.out.println("      testTwo : 2 arguments");
    }

}


/* Write down the following information contained in this file.

Class name:
Basic6


All attribute(field) names:
mX
mY

All operation(method) names:
main
testOne : no argument
testOne : 1 argument
testOne : 2 arguments
testTwo : no argument
testTwo : 1 argument
testTwo : 2 arguments



*/