/*
 * FILE: Shape.java
 * TASK: lab_02
 * LANG: JAVA
 * ID:   xxxxxxxxxx
 */

public class Shape {

    // Attributes (fields)
    String name;
    Integer w;
    Integer h;

    // Operations (methods)
    void setWidth(Integer width) { w = width; }
    void setHeight(Integer height) { h = height; }
    void setName(String s) { name = s; }

    Integer getWidth() { return w; }
    Integer getHeight() { return h; }
    String getName() { return name; }

    void draw() { }

    public static void main(String[] args) {
        System.out.println("In Class: Simple");
        System.out.println("   Fields:");
        System.out.println("      name");
        System.out.println("      w");
        System.out.println("      h");
        System.out.println("   Methods:");
        System.out.println("      main");
        System.out.println("      setWidth");
        System.out.println("      setHeight");
        System.out.println("      setName");
        System.out.println("      getWidth");
        System.out.println("      getHeight");
        System.out.println("      getName");
        System.out.println("      draw");
    }
}

