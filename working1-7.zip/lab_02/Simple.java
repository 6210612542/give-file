/*
 * FILE: Simple.java
 * TASK: lab_02
 * LANG: JAVA
 * ID:   6210612559
 */

public class Simple {

    // Attributes (fields)
    // Write all attribute in Simple class diagram in file simple_class.zargo
    public int a;
    int b;
    protected int c;
    private int d;
    // Operations (methods)
    // Write all methods in Simple class diagram in file simple_class.zargo
    public void testA() {
    }

    void testB() {
    }

    protected void testC() {
    }

    private void testD() {
    }

    public void test() {
    }

    public  void test(int x, int y) {
        return 0;
    }

    // Complete the main method to print out all fields and methods
    public static void main(String[] args) {
        System.out.println("In Class: Simple");
        System.out.println("   Fields: a b c d");
        System.out.println("   Methods:main, testA, testB, testC, testD, test");
    }
}

