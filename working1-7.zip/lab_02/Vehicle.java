/*
 * FILE: Vehicle.java
 * TASK: lab_02
 * LANG: JAVA
 * ID:   xxxxxxxxxx
 */

public class Vehicle {

    // Attributes (fields)
    double speed;

    // Operations (methods)
    void setSpeed(double s) { speed = s; }
    double getSpeed() { return speed; }
}

class Car extends Vehicle {

    // Attributes (fields)
    int numberOfWheels;

    // Operations (methods)
    void setNumberOfWheels(int n) { numberOfWheels = n; }
    int getNumberOfWheels() { return numberOfWheels; }

    public static void main(String[] args) {
        System.out.println("This is a car");
    }
}

class Truck extends Car {

    // Attributes (fields)
    int dutyClass;

    // Operations (methods)
    void setDutyClass(int n) { dutyClass = n; }
    int getDutyClass() { return dutyClass; }

    public static void main(String[] args) {
        System.out.println("This is a truck");
    }
}

