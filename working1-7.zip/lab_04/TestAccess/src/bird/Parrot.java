package bird;

/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxx@cn103>
 */
public class Parrot {
    private int age;

    public Parrot(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    void setAge(int age) {
        this.age = age;
    }
}

