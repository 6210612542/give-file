package bug;

/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxx@cn103>
 */
public class Beetle {
    private int age;

    public Beetle(int age) {
        this.age = age;
    }

    protected int getAge() {
        return age;
    }

    void setAge(int age) {
        this.age = age;
    }
}

