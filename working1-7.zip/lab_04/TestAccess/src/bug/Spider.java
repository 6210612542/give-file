package bug;

/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxx@cn103>
 */
public class Spider {
    private int age;

    public Spider(int age) {
        this.age = age;
    }

    private int getAge() {
        return age;
    }

    void setAge(int age) {
        this.age = age;
    }

}

