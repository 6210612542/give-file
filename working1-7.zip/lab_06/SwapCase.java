/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxx@cn103>
 */

import java.util.Scanner;

public class SwapCase {

    /**
     * Returns a swapped case of the argument string
     * @param s string to be swapped case
     * @return swapped case string
     */
    public static String swapCase(String s) {
        return null;
    }

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        String s;

        System.out.print("Enter a string:  ");
        s = sc.nextLine();

        System.out.println("After swap case: " + swapCase(s));
    }
    
}
