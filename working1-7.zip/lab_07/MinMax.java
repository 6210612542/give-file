/**
 *
 * @author xxxxxxxxxx <xxxxxxxxxxr@cn103>
 */
public class MinMax {
    public static void main(String[] args) {

    }

}

